
class PoolGame {
    constructor() {
        this.canvas = document.getElementById('poolCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.powerSlider = document.getElementById('powerSlider');
        this.takeShotBtn = document.getElementById('takeShot');
        this.startGameBtn = document.getElementById('startGame');
        
        this.setupEventListeners();
        this.resizeCanvas();
        this.initGame();
    }
    
    resizeCanvas() {
        const table = document.querySelector('.pool-table');
        this.canvas.width = table.clientWidth;
        this.canvas.height = table.clientWidth * 0.5; // 2:1 aspect ratio
    }
    
    setupEventListeners() {
        window.addEventListener('resize', () => this.resizeCanvas());
        this.takeShotBtn.addEventListener('click', () => this.takeShot());
        this.startGameBtn.addEventListener('click', () => this.startGame());
    }
    
    initGame() {
        // Initialize game state
        this.gameStarted = false;
        this.currentPlayer = 1;
        this.balls = [];
        
        // Create pool balls
        this.createBalls();
        this.drawTable();
    }
    
    createBalls() {
        // Create cue ball
        this.cueBall = {
            x: this.canvas.width / 4,
            y: this.canvas.height / 2,
            radius: 10,
            color: 'white'
        };
        
        // Create other balls in triangle formation
        const startX = this.canvas.width * 0.7;
        const startY = this.canvas.height / 2;
        const radius = 10;
        const colors = [
            'yellow', 'blue', 'red', 'purple', 
            'orange', 'green', 'maroon', 'black',
            'yellow', 'blue', 'red', 'purple',
            'orange', 'green', 'maroon'
        ];
        
        let row = 0;
        let count = 0;
        
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j <= i; j++) {
                if (count >= 15) break;
                
                this.balls.push({
                    x: startX + (i * radius * 2),
                    y: startY - (i * radius) + (j * radius * 2),
                    radius: radius,
                    color: colors[count],
                    number: count + 1
                });
                count++;
            }
        }
    }
    
    drawTable() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw table
        this.ctx.fillStyle = '#075e07';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw balls
        this.drawBall(this.cueBall);
        this.balls.forEach(ball => this.drawBall(ball));
    }
    
    drawBall(ball) {
        this.ctx.beginPath();
        this.ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        this.ctx.fillStyle = ball.color;
        this.ctx.fill();
        this.ctx.closePath();
        
        // Draw number for non-cue balls
        if (ball.number) {
            this.ctx.fillStyle = 'white';
            this.ctx.font = '8px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(ball.number.toString(), ball.x, ball.y);
        }
    }
    
    takeShot() {
        if (!this.gameStarted) return;
        
        const power = this.powerSlider.value / 100;
        console.log(`Taking shot with power: ${power}`);
        
        // Implement shot logic here
    }
    
    startGame() {
        this.gameStarted = true;
        this.startGameBtn.disabled = true;
        console.log('Game started!');
    }
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const poolGame = new PoolGame();
});