
class ChessGame {
    constructor() {
        this.boardElement = document.getElementById('chessBoard');
        this.startGameBtn = document.getElementById('startGame');
        this.playWithAIBtn = document.getElementById('playWithAI');
        this.playerTurnElement = document.querySelector('.player-turn');
        this.gameStatusElement = document.querySelector('.game-status');
        
        this.gameState = {
            board: [],
            currentPlayer: 'white',
            selectedPiece: null,
            possibleMoves: [],
            vsAI: false
        };
        
        this.setupEventListeners();
        this.initializeBoard();
        this.renderBoard();
    }
    
    setupEventListeners() {
        this.startGameBtn.addEventListener('click', () => this.newGame());
        this.playWithAIBtn.addEventListener('click', () => this.toggleAI());
    }
    
    initializeBoard() {
        // Create initial board setup
        this.gameState.board = Array(8).fill().map(() => Array(8).fill(null));
        
        // Set up pawns
        for (let i = 0; i < 8; i++) {
            this.gameState.board[1][i] = { type: 'pawn', color: 'black' };
            this.gameState.board[6][i] = { type: 'pawn', color: 'white' };
        }
        
        // Set up other pieces
        const pieces = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
        
        for (let i = 0; i < 8; i++) {
            this.gameState.board[0][i] = { type: pieces[i], color: 'black' };
            this.gameState.board[7][i] = { type: pieces[i], color: 'white' };
        }
    }
    
    renderBoard() {
        this.boardElement.innerHTML = '';
        
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const square = document.createElement('div');
                square.className = `chess-square ${(row + col) % 2 === 0 ? 'light' : 'dark'}`;
                square.dataset.row = row;
                square.dataset.col = col;
                
                // Highlight selected square
                if (this.gameState.selectedPiece && 
                    this.gameState.selectedPiece.row === row && 
                    this.gameState.selectedPiece.col === col) {
                    square.classList.add('highlighted');
                }
                
                // Highlight possible moves
                if (this.gameState.possibleMoves.some(move => move.row === row && move.col === col)) {
                    square.classList.add('possible-move');
                }
                
                // Add piece if exists
                const piece = this.gameState.board[row][col];
                if (piece) {
                    const pieceElement = document.createElement('div');
                    pieceElement.className = 'chess-piece';
                    pieceElement.style.backgroundImage = `url('images/chess/${piece.color}-${piece.type}.png')`;
                    pieceElement.addEventListener('click', () => this.handlePieceClick(row, col));
                    square.appendChild(pieceElement);
                }
                
                square.addEventListener('click', () => this.handleSquareClick(row, col));
                this.boardElement.appendChild(square);
            }
        }
        
        // Update player turn display
        this.playerTurnElement.textContent = `${this.gameState.currentPlayer.charAt(0).toUpperCase() + this.gameState.currentPlayer.slice(1)}'s Turn`;
    }
    
    handlePieceClick(row, col) {
        const piece = this.gameState.board[row][col];
        
        // If it's not the player's turn when playing vs AI
        if (this.gameState.vsAI && this.gameState.currentPlayer !== 'white') {
            return;
        }
        
        // If the piece belongs to the current player
        if (piece && piece.color === this.gameState.currentPlayer) {
            this.gameState.selectedPiece = { row, col };
            this.gameState.possibleMoves = this.getPossibleMoves(row, col);
            this.renderBoard();
        }
    }
    
    handleSquareClick(row, col) {
        // If a piece is selected and the square is a possible move
        if (this.gameState.selectedPiece) {
            const isMoveValid = this.gameState.possibleMoves.some(
                move => move.row === row && move.col === col
            );
            
            if (isMoveValid) {
                this.makeMove(
                    this.gameState.selectedPiece.row,
                    this.gameState.selectedPiece.col,
                    row,
                    col
                );
                
                // If playing vs AI, let AI make move
                if (this.gameState.vsAI && this.gameState.currentPlayer === 'black') {
                    setTimeout(() => this.aiMakeMove(), 1000);
                }
            }
        }
    }
    
    getPossibleMoves(row, col) {
        // Simplified movement logic - in a real game this would be more complex
        const piece = this.gameState.board[row][col];
        const moves = [];
        
        if (piece.type === 'pawn') {
            const direction = piece.color === 'white' ? -1 : 1;
            
            // Forward move
            if (this.isValidSquare(row + direction, col) && !this.gameState.board[row + direction][col]) {
                moves.push({ row: row + direction, col });
                
                // Double move from starting position
                const startRow = piece.color === 'white' ? 6 : 1;
                if (row === startRow && !this.gameState.board[row + 2 * direction][col]) {
                    moves.push({ row: row + 2 * direction, col });
                }
            }
            
            // Capture moves
            for (const colOffset of [-1, 1]) {
                const newCol = col + colOffset;
                if (this.isValidSquare(row + direction, newCol) && 
                    this.gameState.board[row + direction][newCol] && 
                    this.gameState.board[row + direction][newCol].color !== piece.color) {
                    moves.push({ row: row + direction, col: newCol });
                }
            }
        }
        
        // Add logic for other pieces here...
        
        return moves;
    }
    
    isValidSquare(row, col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }
    
    makeMove(fromRow, fromCol, toRow, toCol) {
        // Move the piece
        this.gameState.board[toRow][toCol] = this.gameState.board[fromRow][fromCol];
        this.gameState.board[fromRow][fromCol] = null;
        
        // Switch player
        this.gameState.currentPlayer = this.gameState.currentPlayer === 'white' ? 'black' : 'white';
        this.gameState.selectedPiece = null;
        this.gameState.possibleMoves = [];
        
        this.renderBoard();
    }
    
    newGame() {
        this.initializeBoard();
        this.gameState.currentPlayer = 'white';
        this.gameState.selectedPiece = null;
        this.gameState.possibleMoves = [];
        this.renderBoard();
        this.gameStatusElement.textContent = 'Game in progress';
    }
    
    toggleAI() {
        this.gameState.vsAI = !this.gameState.vsAI;
        this.playWithAIBtn.textContent = this.gameState.vsAI ? 'Play vs Human' : 'Play vs AI';
        this.newGame();
    }
    
    aiMakeMove() {
        // Use AI to make a move
        const move = ChessAI.getBestMove(this.gameState.board, 'black');
        
        if (move) {
            this.makeMove(move.fromRow, move.fromCol, move.toRow, move.toCol);
        }
    }
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const chessGame = new ChessGame();
});