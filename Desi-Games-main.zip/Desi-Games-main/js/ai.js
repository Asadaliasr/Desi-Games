
class ChessAI {
    static getBestMove(board, color) {
        // Simplified AI - in a real game this would use minimax algorithm
        
        // Find all pieces of the AI's color
        const pieces = [];
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                if (board[row][col] && board[row][col].color === color) {
                    pieces.push({ row, col, type: board[row][col].type });
                }
            }
        }
        
        // Try to find a capture move
        for (const piece of pieces) {
            const possibleMoves = this.getPossibleMoves(board, piece.row, piece.col);
            
            for (const move of possibleMoves) {
                if (board[move.row][move.col] && board[move.row][move.col].color !== color) {
                    return {
                        fromRow: piece.row,
                        fromCol: piece.col,
                        toRow: move.row,
                        toCol: move.col
                    };
                }
            }
        }
        
        // If no captures, make a random move
        for (const piece of pieces) {
            const possibleMoves = this.getPossibleMoves(board, piece.row, piece.col);
            
            if (possibleMoves.length > 0) {
                const randomMove = possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
                return {
                    fromRow: piece.row,
                    fromCol: piece.col,
                    toRow: randomMove.row,
                    toCol: randomMove.col
                };
            }
        }
        
        return null; // No valid moves found
    }
    
    static getPossibleMoves(board, row, col) {
        // Simplified movement logic - same as in chess.js
        const piece = board[row][col];
        const moves = [];
        
        if (!piece) return moves;
        
        if (piece.type === 'pawn') {
            const direction = piece.color === 'white' ? -1 : 1;
            
            // Forward move
            if (this.isValidSquare(row + direction, col) && !board[row + direction][col]) {
                moves.push({ row: row + direction, col });
                
                // Double move from starting position
                const startRow = piece.color === 'white' ? 6 : 1;
                if (row === startRow && !board[row + 2 * direction][col]) {
                    moves.push({ row: row + 2 * direction, col });
                }
            }
            
            // Capture moves
            for (const colOffset of [-1, 1]) {
                const newCol = col + colOffset;
                if (this.isValidSquare(row + direction, newCol) && 
                    board[row + direction][newCol] && 
                    board[row + direction][newCol].color !== piece.color) {
                    moves.push({ row: row + direction, col: newCol });
                }
            }
        }
        
        // Add logic for other pieces here...
        
        return moves;
    }
    
    static isValidSquare(row, col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }
}