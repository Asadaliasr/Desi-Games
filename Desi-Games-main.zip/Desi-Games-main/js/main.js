<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desi Games - Play Classic Multiplayer Games</title>
    <meta name="description" content="Play classic Desi games like Ludo, Chess, 8 Ball Pool, and Carrom with friends or AI.">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">


        
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container header-content">
            <div class="logo">
                <img src="images/logo.png" alt="Desi Games Logo">
                <h1>Desi Games</h1>
            </div>
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <nav id="mainNav">
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#games">Games</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#how-to-play">How to Play</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero, Games, Ads, Features, Footer (Same as before) -->
    <!-- ... -->

        

    <!-- JavaScript -->
    <script src="script.js"></script>
</body>
</html>
